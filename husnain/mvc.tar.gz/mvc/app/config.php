<?php
define('SERVER_NAME','localhost');
define('USER_NAME','root');
define('PASSWORD','123');
define('DB_NAME','test');