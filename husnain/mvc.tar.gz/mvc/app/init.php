<?php

require_once '../core/App.php';

require_once '../app/models/Student.php';

/*require_once '../app/controllers/StudentController.php';
require_once  '../app/config.php';
require_once '../core/controllers/BaseController.php';
include '../core/controllers/BaseController.php';

require_once '../core/controllers/ControllerFactory.php';
require_once '../core/controllers/ControllerInterface.php';
require_once '../core/models/database';*/
