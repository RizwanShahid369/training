<?php
//error_reporting(E_ALL & ~E_NOTICE);
error_reporting(E_ERROR | E_WARNING | E_PARSE);
ini_set("display_errors", "On");


require_once '../app/init.php';



$app = new App();
