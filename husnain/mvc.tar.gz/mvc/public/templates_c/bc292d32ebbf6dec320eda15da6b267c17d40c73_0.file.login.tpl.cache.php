<?php
/* Smarty version 3.1.28, created on 2016-06-23 01:49:42
  from "/var/www/html/training/training/husnain/mvc/app/views/student/login.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.28',
  'unifunc' => 'content_576b787614f5f4_03216985',
  'file_dependency' => 
  array (
    'bc292d32ebbf6dec320eda15da6b267c17d40c73' => 
    array (
      0 => '/var/www/html/training/training/husnain/mvc/app/views/student/login.tpl',
      1 => 1466659946,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576b787614f5f4_03216985 ($_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '194284337576b7876143b74_02743704';
?>

<h4>this is login pahe</h4>

<form method="POST">
    Username:<br>
    <input type="text" name="username"><br>
    Password:<br>
    <input type="password" name="password"><br>
    <input type="submit">

</form><?php }
}
