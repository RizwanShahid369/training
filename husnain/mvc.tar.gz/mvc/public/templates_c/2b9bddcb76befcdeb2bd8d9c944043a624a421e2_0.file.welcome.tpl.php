<?php
/* Smarty version 3.1.28, created on 2016-06-23 07:09:54
  from "/var/www/html/training/training/husnain/mvc/app/views/student/welcome.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.28',
  'unifunc' => 'content_576bc382585305_53490770',
  'file_dependency' => 
  array (
    '2b9bddcb76befcdeb2bd8d9c944043a624a421e2' => 
    array (
      0 => '/var/www/html/training/training/husnain/mvc/app/views/student/welcome.tpl',
      1 => 1466680189,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_576bc382585305_53490770 ($_smarty_tpl) {
?>
<h2>Welcome Page</h2>

<ul>
    <li><a href="student/listt">List All Students</a> </li>
    <li><a href="student/add">Add New Students</a> </li>
</ul>
<a href="student/logout">LogOut</a><?php }
}
