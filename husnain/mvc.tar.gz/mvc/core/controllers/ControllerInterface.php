<?php

/**
 * Created by PhpStorm.
 * User: husnain.zaheer
 * Date: 6/20/16
 * Time: 2:56 AM
 */
interface ControllerInterface
{
    public function add();
    public function edit();
    public function delete();
    public function listt();
}